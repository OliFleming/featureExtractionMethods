function checkamp
lowGet = zeros(M15_NCH,1);
highGet = zeros(M15_NCH,1);
gainGet = zeros(M15_NCH,1);
lineGet = zeros(M15_NCH,1);
for i = 1:M15_NCH
    pause(0.1)
    [highGeti, lineGeti, gainGeti, lowGeti] = M15_QuerySettings(i);
    highGet(i) = highGeti;
    lowGet(i) = lowGeti;
    gainGet(i) = gainGeti;
    lineGet(i) = strcmpi(lineGeti,'ON');
end
fprintf('%15d %15d %15d %15d\n',[lowGet highGet gainGet lineGet]')