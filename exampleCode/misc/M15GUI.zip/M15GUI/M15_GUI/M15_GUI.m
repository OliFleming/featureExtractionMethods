%
% M15_GUI This is a M-file for M15_GUI.fig.
%
% function M15_GUI(varargin)
%
% Author Adrian Chan
%
% This function invokes callback functions associated with all the
% objects in the M15_GUI.fig. This is based on the design by
% Aarti Goge and made to be easily expandable for more than eight
% channels.
%
% Use M15_NCH to change the number of amplifiers from 1 - 16
%
% Inputs
%    varargin: command line arguments to M15_GUI 
%
% Outputs
%    none 
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 05/09/19 AC First created.
function varargout = M15_GUI(varargin)
% M15_GUI M-file for M15_GUI.fig
%      M15_GUI, by itself, creates a new M15_GUI or raises the existing
%      singleton*.
%
%      H = M15_GUI returns the handle to a new M15_GUI or the handle to
%      the existing singleton*.
%
%      M15_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in M15_GUI.M with the given input arguments.
%
%      M15_GUI('Property','Value',...) creates a new M15_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before M15_GUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to M15_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help M15_GUI

% Last Modified by GUIDE v2.5 20-Sep-2005 08:24:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @M15_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @M15_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before M15_GUI is made visible.
function M15_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to M15_GUI (see VARARGIN)

% Choose default command line output for M15_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes M15_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);
h = waitbar(0,'Initializing');
pause(0.1)
for iCh = 1:M15_NCH
    waitbar(iCh/M15_NCH,h);
    M15_ElectrodeTest('off',iCh);
    pause(0.01);
end
close(h)
readAmpSettings(handles)

% --- Outputs from this function are returned to the command line.
function varargout = M15_GUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function M15_CreateFcn(hObject,eventdata,handles)
M15_InitializeGui;
         
function M15_CloseRequestFcn(hObject,eventdata,handles)
M15_DestroyGui
closereq

% --- Executes during object creation, after setting all properties.
function hLow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hLow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function hHigh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hHigh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function hGain_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hGain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on button press in hChAll.
function hChAll_Callback(hObject, eventdata, handles)
% hObject    handle to hChAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of hChAll

allOn = get(hObject,'Value');
channelEnable(handles,0,allOn);
for ampNum = 1:M15_NCH
    eval(['chOn = get(handles.hCh' int2str(ampNum) ',''Value'');']);
    channelEnable(handles,ampNum,(~allOn)&chOn);
    if allOn
        eval(['set(handles.hCh' int2str(ampNum) ',''Enable'',''off'')']);
    else
        eval(['set(handles.hCh' int2str(ampNum) ',''Enable'',''on'')']);
    end
end

writeAmpSettings(handles)

% --- Executes on selection change in hLowAll.
function hLowAll_Callback(hObject, eventdata, handles)
% hObject    handle to hLowAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hLowAll contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hLowAll
h = waitbar(0,'Setting low filter parameters');
for ampNum = 1:M15_NCH
    waitbar(ampNum/M15_NCH,h)
    setLowFilter(handles,ampNum,get(handles.hLowAll,'Value'));
end
close(h)

% --- Executes on selection change in hHighAll.
function hHighAll_Callback(hObject, eventdata, handles)
% hObject    handle to hHighAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hHighAll contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hHighAll
h = waitbar(0,'Setting high filter parameters');
for ampNum = 1:M15_NCH
    waitbar(ampNum/M15_NCH,h)
    setHighFilter(handles,ampNum,get(handles.hHighAll,'Value'));
end
close(h)

% --- Executes on selection change in hGainAll.
function hGainAll_Callback(hObject, eventdata, handles)
% hObject    handle to hGainAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hHighAll contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hHighAll
h = waitbar(0,'Setting gain parameters');
for ampNum = 1:M15_NCH
    waitbar(ampNum/M15_NCH,h)
    setGain(handles,ampNum,get(handles.hGainAll,'Value'));
end
close(h)

% --- Executes on selection change in hLineAll.
function hLineAll_Callback(hObject, eventdata, handles)
% hObject    handle to hLineAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hHighAll contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hHighAll
h = waitbar(0,'Setting line filter parameters');
for ampNum = 1:M15_NCH
    waitbar(ampNum/M15_NCH,h)
    setLineFilter(handles,ampNum,get(handles.hLineAll,'Value'));
end
close(h)

% --- Executes on selection change in hChX.
function hCh_Callback(hObject, eventdata, handles,ampNum)
% hObject    handle to hChX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of hChX

chOn = get(hObject,'Value');
channelEnable(handles,ampNum,chOn);
ampStr = int2str(ampNum);
if chOn
    eval(['lowSet = get(handles.hLow' ampStr ',''Value'');']);
    eval(['highSet = get(handles.hHigh' ampStr ',''Value'');']);
    eval(['gainSet = get(handles.hGain' ampStr ',''Value'');']);
    eval(['lineSet = get(handles.hLine' ampStr ',''Value'');']);
    setLowFilter(handles,ampNum,lowSet);
    setHighFilter(handles,ampNum,highSet);
    setGain(handles,ampNum,gainSet);
    setLineFilter(handles,ampNum,lineSet);
else    
    M15_TurnOffChannel(ampNum);
end
    

% --- Executes on selection change in hLowX.
function hLow_Callback(hObject, eventdata, handles,ampNum)
% hObject    handle to hLowX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hLow1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hLowX

setLowFilter(handles,ampNum,get(hObject,'Value'));

% --- Executes on selection change in hHighX.
function hHigh_Callback(hObject, eventdata, handles,ampNum)
% hObject    handle to hHighX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hLow1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hHighX

setHighFilter(handles,ampNum,get(hObject,'Value'));

% --- Executes on selection change in hGainX.
function hGain_Callback(hObject, eventdata, handles,ampNum)
% hObject    handle to hGainX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hLow1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hGainX

setGain(handles,ampNum,get(hObject,'Value'));

% --- Executes on button press in hLineX.
function hLine_Callback(hObject, eventdata, handles,ampNum)
% hObject    handle to hLineX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of hLineX

setLineFilter(handles,ampNum,get(hObject,'Value'));

% --------------------------------------------------------------------
%
% channelEnable Turns the enable for channel parameters on/off.
%
% function channelEnable(handles,ampNum,enable)
%
% Note that this function does not turn off the amplifier. Just
% the GUI enable parameters.
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%    ampNum: amplifier number to enable/disable
%    enable: value 1 for on, value 0 for off
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function channelEnable(handles,ampNum,enable)

if ampNum == 0
    ampstr = 'All';
else
    ampstr = int2str(ampNum);
end

if enable
    eval(['set(handles.hLow' ampstr ',''Enable'', ''on'')']);
    eval(['set(handles.hHigh' ampstr ',''Enable'', ''on'')']);
    eval(['set(handles.hGain' ampstr ',''Enable'', ''on'')']);
    eval(['set(handles.hLine' ampstr ',''Enable'', ''on'')']);
else
    eval(['set(handles.hLow' ampstr ',''Enable'', ''off'')']);
    eval(['set(handles.hHigh' ampstr ',''Enable'', ''off'')']);
    eval(['set(handles.hGain' ampstr ',''Enable'', ''off'')']);
    eval(['set(handles.hLine' ampstr ',''Enable'', ''off'')']);
end

% --------------------------------------------------------------------
%
% setLowFilter Sets the low filter setting for an amplifier.
%
% function setLowFilter(handles,ampNum,lowSet)
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%    ampNum: amplifier number to enable/disable
%    setLow: low filter setting
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function setLowFilter(handles,ampNum,lowSet)

lowOption = [0.01 0.1 0.3 1 3 10 30 100];
lowSet = lowOption(lowSet);
error = M15_SetLowFilter(lowSet,ampNum);
[highGet, lineGet, gainGet, lowGet] = M15_QuerySettings(ampNum);
if (lowSet ~= lowGet)
    eval(['set(handles.hLow' int2str(ampNum) ',''Value'', ' find(lowGet==lowOption) ')']);
    set(handles.hErrorMsg,'String',[datestr(clock) ': Low filter setting failed.']);    
end

% --------------------------------------------------------------------
%
% setHighFilter Sets the high filter setting for an amplifier.
%
% function setHighFilter(handles,ampNum,highSet)
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%    ampNum: amplifier number to enable/disable
%    setHigh: high filter setting
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function setHighFilter(handles,ampNum,highSet)

highOption = [30 100 300 1000 6000];
highSet = highOption(highSet);
error = M15_SetHighFilter(highSet,ampNum);
[highGet, lineGet, gainGet, lowGet] = M15_QuerySettings(ampNum);
if (highSet ~= highGet)
    eval(['set(handles.hHigh' int2str(ampNum) ',''Value'', ' find(highGet==highOption) ')']);
    set(handles.hErrorMsg,'String',[datestr(clock) ': High filter setting failed.']);    
end

% --------------------------------------------------------------------
%
% setGain Sets the gain setting for an amplifier.
%
% function setGain(handles,ampNum,gainSet)
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%    ampNum: amplifier number to enable/disable
%    gainSet: gain setting
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function setGain(handles,ampNum,gainSet)

gainOption = [50 100 200 500 1000 2000 5000 10000 20000 50000 100000 200000];
gainSet = gainOption(gainSet);
error = M15_SetGain(gainSet,ampNum);
[highGet, lineGet, gainGet, lowGet] = M15_QuerySettings(ampNum);
if (gainSet ~= gainGet)
    eval(['set(handles.hGain' int2str(ampNum) ',''Value'', ' find(gainGet==gainOption) ')']);
    set(handles.hErrorMsg,'String',[datestr(clock) 'Gain setting failed.']);    
end

% --------------------------------------------------------------------
%
% setLineFilter Sets the line filter setting for an amplifier.
%
% function setLineFilter(handles,ampNum,lineSet)
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%    ampNum: amplifier number to enable/disable
%    setLine: 1 for on, 0 for off
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function setLineFilter(handles,ampNum,lineSet)

if (lineSet)
    lineSet = 'ON';
else
    lineSet = 'OFF';
end
error = M15_SetLineFilter(lineSet,ampNum);
[highGet, lineGet, gainGet, lowGet] = M15_QuerySettings(ampNum);
if (~strcmpi(lineSet,lineGet))
    if strcmpi(lineGet,'OFF')
        eval(['set(handles.hLine' int2str(ampNum) ',''Value'',0)']);
    else
        eval(['set(handles.hLine' int2str(ampNum) ',''Value'',1)']);
    end
    set(handles.hErrorMsg,'String',[datestr(clock) ': Line filter setting failed.']);    
end


% --------------------------------------------------------------------
function hMenuFile_Callback(hObject, eventdata, handles)
% hObject    handle to hFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function hMenuOpen_Callback(hObject, eventdata, handles)
% hObject    handle to hOpen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname, filterindex] = uigetfile('*.mat', 'Pick an mat-file', 'default.mat');
if filename ~= 0
    filename = [pathname filename];
    if exist(filename,'file')
        load(filename)
        
        fileOK = true;
        fileOK = fileOK & exist('chVec','var');
        fileOK = fileOK & exist('lowVec','var');
        fileOK = fileOK & exist('highVec','var');
        fileOK = fileOK & exist('gainVec','var');
        fileOK = fileOK & exist('lineVec','var');
        if (fileOK)
            fileOK = fileOK & (size(chVec,1) == 1) & (size(chVec,2) == M15_NCH+1);
            fileOK = fileOK & (size(lowVec,1) == 1) & (size(lowVec,2) == M15_NCH+1);
            fileOK = fileOK & (size(highVec,1) == 1) & (size(highVec,2) == M15_NCH+1);
            fileOK = fileOK & (size(gainVec,1) == 1) & (size(gainVec,2) == M15_NCH+1);
            fileOK = fileOK & (size(lineVec,1) == 1) & (size(lineVec,2) == M15_NCH+1);
        end
        if ~fileOK
            set(handles.hErrorMsg,'String',[datestr(clock) ': Error reading ' filename '.']);
            return
        end
        
        allOn = chVec(M15_NCH+1);
        channelEnable(handles,0,allOn);
        eval(['set(handles.hChAll,''Value'', ' int2str(chVec(M15_NCH+1)) ')']);
        eval(['set(handles.hLowAll,''Value'', ' int2str(lowVec(M15_NCH+1)) ')']);
        eval(['set(handles.hHighAll,''Value'', ' int2str(highVec(M15_NCH+1)) ')']);
        eval(['set(handles.hGainAll,''Value'', ' int2str(gainVec(M15_NCH+1)) ')']);
        eval(['set(handles.hLineAll,''Value'', ' int2str(lineVec(M15_NCH+1)) ')']);
        for ampNum = 1:M15_NCH
            ampstr = int2str(ampNum);
            eval(['set(handles.hCh' ampstr ',''Value'', ' int2str(chVec(ampNum)) ')']);
            eval(['set(handles.hLow' ampstr ',''Value'', ' int2str(lowVec(ampNum)) ')']);
            eval(['set(handles.hHigh' ampstr ',''Value'', ' int2str(highVec(ampNum)) ')']);
            eval(['set(handles.hGain' ampstr ',''Value'', ' int2str(gainVec(ampNum)) ')']);
            eval(['set(handles.hLine' ampstr ',''Value'', ' int2str(lineVec(ampNum)) ')']);
            channelEnable(handles,ampNum,chVec(ampNum)&~allOn);
            if allOn
                eval(['set(handles.hCh' ampstr ',''Enable'',''off'')']);
            else
                eval(['set(handles.hCh' ampstr ',''Enable'',''on'')']);
            end
        end
    end
    writeAmpSettings(handles)
end

% --------------------------------------------------------------------
function hMenuSaveAs_Callback(hObject, eventdata, handles)
% hObject    handle to hSaveAs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname, filterindex] = uiputfile('*.mat', 'Save workspace as', 'default.mat');
if filename ~= 0
    filename = [pathname filename];
    for ampNum = 1:M15_NCH
        ampstr = int2str(ampNum);
        eval(['chVec(ampNum) = get(handles.hCh' ampstr ',''Value'');']);
        eval(['lowVec(ampNum) = get(handles.hLow' ampstr ',''Value'');']);
        eval(['highVec(ampNum) = get(handles.hHigh' ampstr ',''Value'');']);
        eval(['gainVec(ampNum) = get(handles.hGain' ampstr ',''Value'');']);
        eval(['lineVec(ampNum) = get(handles.hLine' ampstr ',''Value'');']);
    end
    eval(['chVec(M15_NCH+1) = get(handles.hChAll,''Value'');']);
    eval(['lowVec(M15_NCH+1) = get(handles.hLowAll,''Value'');']);
    eval(['highVec(M15_NCH+1) = get(handles.hHighAll,''Value'');']);
    eval(['gainVec(M15_NCH+1) = get(handles.hGainAll,''Value'');']);
    eval(['lineVec(M15_NCH+1) = get(handles.hLineAll,''Value'');']);
    save(filename,'chVec','lowVec','highVec','gainVec','lineVec');
end

% --------------------------------------------------------------------
function hMenuHelp_Callback(hObject, eventdata, handles)
% hObject    handle to hHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function hMenuAbout_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

M15_About


% --------------------------------------------------------------------
function hReset_Callback(hObject, eventdata, handles)
% hObject    handle to hMenuReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

for ampNum = 1:M15_NCH
    channelEnable(handles,ampNum,0)
    ampstr = int2str(ampNum);
    eval(['set(handles.hCh' ampstr ',''Enable'',''on'')']);
    eval(['set(handles.hCh' ampstr ',''Value'',0)']);
    eval(['set(handles.hLow' ampstr ',''Value'',8)']);
    eval(['set(handles.hHigh' ampstr ',''Value'',1)']);
    eval(['set(handles.hGain' ampstr ',''Value'',1)']);
    eval(['set(handles.hLine' ampstr ',''Value'',0)']);
end

channelEnable(handles,0,0)
eval(['set(handles.hChAll,''Enable'', ''on'')']);
eval(['set(handles.hChAll,''Value'', 0)']);
eval(['set(handles.hLowAll,''Value'', 8)']);
eval(['set(handles.hHighAll,''Value'', 1)']);
eval(['set(handles.hGainAll,''Value'', 1)']);
eval(['set(handles.hLineAll,''Value'', 0)']);
writeAmpSettings(handles)

% --------------------------------------------------------------------
%
% readAmpSettings Sets the GUI values to current amplifier settings.
%
% function readAmpSettings(handles)
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function readAmpSettings(handles)

lowOption = [0.01 0.1 0.3 1 3 10 30 100];
highOption = [30 100 300 1000 6000];
gainOption = [50 100 200 500 1000 2000 5000 10000 20000 50000 100000 200000];

h = waitbar(0,'Reading amplifier settings');
pause(0.5)
for ampNum = 1:M15_NCH
    waitbar(ampNum/M15_NCH,h);
    [highGet, lineGet, gainGet, lowGet] = M15_QuerySettings(ampNum);
    ampstr = int2str(ampNum);
    
    eval(['set(handles.hCh' ampstr ',''Enable'',''on'')']);
    
    chOn = ~(lowGet == 100 & highGet == 30 & gainGet == 50 & strcmpi(lineGet,'OFF'));
    eval(['set(handles.hCh' ampstr ',''Value'',' int2str(chOn) ')']);
    channelEnable(handles,ampNum,chOn);
    
    lowValue = int2str(find(lowGet == lowOption));
    eval(['set(handles.hLow' ampstr ',''Value'',' lowValue ')']);
    highValue = int2str(find(highGet == highOption));
    eval(['set(handles.hHigh' ampstr ',''Value'',' highValue ')']);
    gainValue = int2str(find(gainGet == gainOption));
    eval(['set(handles.hGain' ampstr ',''Value'',' gainValue ')']);
    if (strcmpi(lineGet,'off'))
        eval(['set(handles.hLine' ampstr ',''Value'',0)']);
    else
        eval(['set(handles.hLine' ampstr ',''Value'',1)']);
    end
end
pause(0.5)
close(h)
channelEnable(handles,0,0);
eval(['set(handles.hChAll,''Enable'', ''off'')']);
eval(['set(handles.hChAll,''Value'', 0)']);
eval(['set(handles.hLowAll,''Value'', 8)']);
eval(['set(handles.hHighAll,''Value'', 1)']);
eval(['set(handles.hGainAll,''Value'', 1)']);
eval(['set(handles.hLineAll,''Value'', 0)']);

% --------------------------------------------------------------------
%
% writeAmpSettings Sets amplifier to current GUI values.
%
% function writeAmpSettings(handles)
%
% Author Adrian Chan
%
% Inputs
%    handles: structure with handles and user data
%
% Outputs
%    none 
%
% Modifications
% 05/09/19 AC First created.
function writeAmpSettings(handles)

allOn = get(handles.hChAll,'Value');
h = waitbar(0,'Setting amplifier parameters');
pause(0.5)
if allOn
    for ampNum = 1:M15_NCH
        waitbar(ampNum/M15_NCH,h);
        setLowFilter(handles,ampNum,get(handles.hLowAll,'Value'));
        setHighFilter(handles,ampNum,get(handles.hHighAll,'Value'));
        setGain(handles,ampNum,get(handles.hGainAll,'Value'));
        setLineFilter(handles,ampNum,get(handles.hLineAll,'Value'));
    end
else
    for ampNum = 1:M15_NCH
        waitbar(ampNum/M15_NCH,h);
        eval(['chOn = get(handles.hCh' int2str(ampNum) ',''Value'');']);
        if chOn
            eval(['lowSet = get(handles.hLow' int2str(ampNum) ',''Value'');']);
            eval(['highSet = get(handles.hHigh' int2str(ampNum) ',''Value'');']);
            eval(['gainSet = get(handles.hGain' int2str(ampNum) ',''Value'');']);
            eval(['lineSet = get(handles.hLine' int2str(ampNum) ',''Value'');']);
            setLowFilter(handles,ampNum,lowSet);
            setHighFilter(handles,ampNum,highSet);
            setGain(handles,ampNum,gainSet);
            setLineFilter(handles,ampNum,lineSet);
        else
            M15_TurnOffChannel(ampNum);
        end
    end
end
pause(0.5)
close(h)
