%
% M15_WhoYouAre Create the command to be sent. Write the command to the serial port 
% and read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_WhoYouAre
%
% Author Aarti Goge
%
% This function is used to tells the Model 15 what type of amplifier module is in each 
% slot. Without this the commands will not be sent properly. This should be sent every 
% time a new connection is established with the Model 15.  
%
% Inputs
%    ampconfig: a decimal array of amplifier setting in slots 1 to 8 of the
%    current amplifier system.
%
% Outputs
%    none
%
% Modifications
% 03/06/18 AG First created.
%
function M15_WhoYouAre(ampconfig)

if (nargin==0)
    % default amplifier setting
    ampconfig = [0 0 0 0 9 9 9 9];
end

N = max(size(ampconfig));
if (N<8)
    error('Invalid input: Please enter valid amplifier setting for the Current System.');
end

% Astro-Med Inc., Grass 15 & 15LT Amplifier System - Instruction/User Manual, Release A Grass
% Telefactor, West Warwick RI, 2002, p.A-5
%
% setting	                    hexadecimal	char
% 15A54 or 15A94 Amplifier	    30 	        0
% 15A12 Amplifier	            31 	        1
% Empty slot, 15A04 or 15A02	39 	        9
command = '';
for(i=1:8)
    % check if the input is as per the manual setting
    if ((ampconfig(i)==0)||(ampconfig(i)==1)||(ampconfig(i)==9))       
        % write formatted data to a string
        s = sprintf('%u',ampconfig(i)); 
        command = [command s];
    else
        error('Invalid input: Please enter valid amplifier setting(0,1,or9) for the Current System.');
    end
end
    

% check if the string consists of 8 characters, else add '0' at the beginning of the string 
% to make it 8 characters
%s = max(size(whoyouare));
%if (s<8)
%    s = 8-s;
%    while (s>0)
%        whoyouare = ['0' whoyouare];
%        s=s-1;
%    end
%end

% create the command
command = ['F' command];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead;

% check the status code of the response
[code errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);