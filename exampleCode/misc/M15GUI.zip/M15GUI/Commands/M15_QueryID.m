%
% M15_QueryID Create and write the command to be sent to the serial port.
% Read the response from the serial port and output the Model 15 firmware revision 
% number.
%
% function M15_QueryID
%
% Author Aarti Goge
%
% This function is used to obtain the Model 15 firmware revision number.
%
% Inputs
%    none
%
% Outputs
%    firmwarenum: the Model 15 firmware revision number(string)
%
% Modifications
% 03/06/18 AG First created.
%
function firmwarenum = M15_QueryID

% create the command
command = ['U']; 

% write the command to the serial port
M15_SerialWrite(command)

% read the repsponse from the serial port
response = M15_SerialRead;

% check the status code of the response
[code errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);

% read the repsponse from the serial port
firmwarenum = M15_SerialRead;

% don't need this cause: M15_InitializeSerialPort-->waiting for <cr>
% carriage --> can get response in two SerialRead...
% check if firmwarenum starts with 'OK'
%if (strncmp('OK',firmwarenum,2))--------------->v= 4:(4+27)
%if (~isempty(strfind(firmwarenum,'O'))&&~isempty(strfind(firmwarenum,'K'))) 
    % need to output 'GRASS Model 15 Rev.XX.XX<cr>'
%    v = 5:(5+26);
%    firmwarenum = firmwarenum(v);
%end