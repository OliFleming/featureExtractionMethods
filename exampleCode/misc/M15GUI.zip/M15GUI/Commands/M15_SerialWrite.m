%
% M15_SerialWrite Add escape character and address at the beginning of the command.
% Add checksum and carriage return at the end of the command and write the command 
% to the device.
%
% function M15_SerialWrite(command)
%
% Author Aarti Goge
%
% This function is used to write a command to the serial port. 
%
% Inputs
%    command: ASCII string to be written to the serial port 
%
% Outputs
%    none
%
% Globals
%    M15_SerialPort: serial port object
%    M15_Address: address of the Model 15 system
%
% Modifications
% 03/06/18 AG First created.
%
function M15_SerialWrite(command)

% constants
M15_ESC = 27;
M15_CR = 13;

% gobal variables
global M15_SerialPort M15_Address;  

% add escape character and Model 15 address at the beginning of command
command = [M15_ESC M15_Address command];
% add checksum and carriage return at the end of command
command = [command M15_CheckSum(command) M15_CR];

% write data to the device
fprintf(M15_SerialPort,command);