%
% M15_Initialize Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_Initialize
%
% Author Aarti Goge
%
% This function is used to initialize all amplifiers to the non-volatile default 
% settings and clear any pending errors.
%
% Inputs
%    none
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_Initialize

global M15_OK M15_DEBUG;

% create the command
command = ['I'];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead;

% check the status code of the response
[code, errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code, errormsg);

if M15_DEBUG
    if (code==M15_OK)
        % send M15_QuerySettings only once, as all amplifiers are initialzed
        % to same setting
        disp('All amplifiers are initialized to the setting as follows:')
        disp('High Filter = 30 Hz')
        disp('Low Filter = 1.0 Hz')
        disp('Line Filter = OFF')
        disp('Gain Range = 1000')
        disp('Gain = 10')
    end 
end