%
% M15_TestProgram
%
% Author Aarti Goge
%
% This program is used to test all the commands/functions to be sent to the Model 15
% amplifier system.
%
% Inputs
%    none
%
% Outputs
%    none
%
% Modifications
% 03/07/10 AG First created.
%
highfilter = [30 100 300 1000 3000 6000];
lowfilter = [0.01 0.1 0.3 1.0 3.0 10 30 100];
linefilter = ['off' 'on'];
gain = [5 10 20 50 100 200];
gainrange = [1000 10];

%--------------------------------------------------------------------
% testing system commands
%--------------------------------------------------------------------
% initialize serial port
disp(' ')
disp(['Initializing Serial Port...'])
M15_InitializeSerialPort

% tell the Model 15 what type of amplifier module is in each slot
disp(' ')
disp(['Sending M15_WhoYouAre---default setting'])
M15_WhoYouAre

% initialize all amplifiers to the non-volatile default settings 
% and clear any pending errors
% High Filter = 30Hz, Low Filter = 1.0 Hz, Line Filter = OFF, Gain Range =
% 1000, Gain = 10
disp(' ')
disp(['Initializing all amplifiers to default setting...'])
M15_Initialize

% obtain the Model 15 firmware revision number
disp(' ')
disp(['Sending M15_QueryID to get the Model 15 firmware revision #'])
firmwarenumber = M15_QueryID

% set the Model 15 into either the Calibration mode
M15_SetMode('cal')

M15_CalSettings('voltage',50)

M15_CalSettings('frequency',1)

% set the Model 15 into either the Use mode
M15_SetMode('use')

% check the status of the Model 15
M15_QueryStatus

%--------------------------------------------------------------------------
% testing amplifier commands
%--------------------------------------------------------------------------
% all channel basis
disp(' ')
disp(['Sending M15_AllChannelBasis([2 4 6 8])'])
M15_AllChannelBasis([2 4 6 8])

% set high filter=3000Hz for amplifiers in all channel basis
disp(' ')
disp(['Sending M15_SetHighFilter(3000)----affects channels in M15_AllChannelBasis'])
M15_SetHighFilter(100)

% set low filter=3Hz for amplifiers in all channel basis
disp(' ')
disp(['Sending M15_SetLowFilter(3)----affects channels in M15_AllChannelBasis'])
M15_SetLowFilter(3)

% set line filter='off' for amplifiers in all channel basis
disp(' ')
disp(['Sending M15_SetLineFilter(off)----affects channels in M15_AllChannelBasis'])
M15_SetLineFilter('off')

% set gain range=1000 for amplifiers in all channel basis
disp(' ')
disp(['Sending M15_SetGainRange(1000)----affects channels in M15_AllChannelBasis'])
M15_SetGainRange(1000)

% set gain=5 for amplifiers in all channel basis
disp(' ')
disp(['Sending M15_SetGain(5)----affects channels in M15_AllChannelBasis'])
M15_SetGain(5)









%--------------------------------------------------------------------------
% destroy serial port
disp(' ')
disp(['Destroying Serial Port'])
M15_DestroySerialPort;