%
% M15_VerifyCode Ouput an error message if the code does not correspond 
% to 'OK'.
%
% function M15_VerifyCode(code,errormsg)
%
% Author Aarti Goge
%
% This function is used to verify if the code is 'OK'. If not, it outputs
% an appropriate error message.
%
% Inputs
%    code: constant value associated with errormsg(integer)
%    errormsg: error message received(string)
%
% Outputs
%    none
%
% Globals
% M15_OK: code corresponding to the response OK<cr>
%
% Modifications
% 03/06/18 AG First created.
%
function M15_VerifyCode(code,errormsg)

global M15_OK;

if (code ~= M15_OK)
    fprintf(errormsg);
end