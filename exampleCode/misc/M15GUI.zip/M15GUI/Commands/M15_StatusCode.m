%
% M15_StatusCode Resolve the response into appropriate code and error message.
%
% function [code,errormsg] = M15_StatusCode(response)
%
% Author Aarti Goge
%
% This function is used to check if the response is 'OK' or 'CM' or 'CK' or
% 'CH' or 'VU'. For every response, there is a corresponding code and error message. 
% 
% response   code       errormsg
% OK<cr>     M15_OK     command accepted/executed
% CM<cr>     M15_CM     command/data error
% CK<cr>     M15_CK     checksum error
% CH<cr>     M15_CH     invalid channel number
% VU<cr>     M15_VU     invalid setting/value
% 
% Inputs
%    response: message received after sending the command to the Model 15 system
%
% Outputs
%    code: constant value associated with errormsg(integer)
%    errormsg: error message received(string)
%
% Globals
%    M15_OK: code corresponding to the response OK<cr>
%    M15_CM: code corresponding to the response CM<cr>
%    M15_CK: code corresponding to the response CK<cr>
%    M15_CH: code corresponding to the response CH<cr>
%    M15_VU: code corresponding to the response VU<cr>
%    M15_NA: code does not correspond to any response
%
% Modifications
% 03/06/18 AG First created.
%
function [code,errormsg] = M15_StatusCode(response)

% global constants
global M15_OK M15_CM M15_CK M15_CH M15_VU M15_NA;

M15_OK = 0;
M15_CM = 1;
M15_CK = 2;
M15_CH = 3;
M15_VU = 4;
M15_NA = 5;

%if (strncmp('OK',response,2))
%    code = M15_OK;
%    errormsg = 'command accepted/executed';

if (~isempty(strfind(response,'O'))&&~isempty(strfind(response,'K')))
    code = M15_OK;
    errormsg = 'command accepted/executed';

elseif (~isempty(strfind(response,'C'))&&~isempty(strfind(response,'M')))
    code = M15_CM;
    errormsg = 'command/data error';
    
elseif (~isempty(strfind(response,'C'))&&~isempty(strfind(response,'K')))
    code = M15_CK;
    errormsg = 'checksum error';
    
elseif (~isempty(strfind(response,'C'))&&~isempty(strfind(response,'H')))
    code = M15_CH;
    errormsg = 'invalid channel number';
    
elseif (~isempty(strfind(response,'V'))&&~isempty(strfind(response,'U')))
    code = M15_VU;
    errormsg = 'invalid setting/value';
else
    code = M15_NA;
    errormsg = 'unresolved error message';
end    