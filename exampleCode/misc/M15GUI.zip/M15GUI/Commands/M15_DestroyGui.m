%
% M15_InitializeGui Invoke M15_DestroySerialPort.
%
% function M15_DestroyGui
%
% Author Aarti Goge
%
% This function is used to in the DestroyFcn of M15_GUI. 
%
% Inputs
%    none
%
% Outputs
%    none
%
% Modifications
% 03/08/19 AG First created.
%
function M15_DestroyGui

M15_DestroySerialPort;