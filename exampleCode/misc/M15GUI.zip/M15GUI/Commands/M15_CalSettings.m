%
% M15_CalSettings Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_CalSettings(volfreq,setting)
%
% Author Aarti Goge
%
% This function is used to sets the calibrator frequency and amplitude. 
% One of the two inputs designates whether the command is for the frequency or 
% amplitude setting. The other input designates the setting itself.
%
% Inputs
%    volfreq: 'voltage' or 'frequency'
%    setting: voltage or frequency value (decimal)
%
% Outputs
%    none
%
% Globals
%    M15_CalFlag: calibration mode flag (if the mode is set to calibration,
%    M15_CalFlag is set to 1, else 0)
%    M15_DcFlag: DC flag (if the frequency is set to 0 for DC then the flag
%    is set to 1, else 0)
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_CalSettings(volfreq,setting)

global M15_CalFlag M15_DcFlag M15_DEBUG;

if(M15_CalFlag~=1)
    error('The system must be in Calibration mode in order to set voltage/frequency.');
end

if(nargin==0)
    error('Please enter valid inputs: volfreq(voltage/frequency) and appropriate setting.');
end

% initialize parameter1 based on volfreq('A' for 'voltage' and 'F' for 'frequency')
if (strcmpi(volfreq,'voltage'))
    parameter1 = 'A';
elseif (strcmpi(volfreq,'frequency'))
    parameter1 = 'F';
else 
    error('Invalid Input: Please enter valid input as voltage or frequency(case insensitive)');
end

% initialize parameter2 based on volfreq and setting
if (strcmpi(volfreq,'voltage'))
    if (setting==5)
        parameter2 = '0';
    elseif (setting==10)
        parameter2 = '1';
    elseif (setting==20)
        parameter2 = '2';
    elseif (setting==50)
        parameter2 = '3';
    elseif (setting==100)
        parameter2 = '4';
    elseif (setting==200)
        parameter2 = '5';
    elseif (setting==500)
        parameter2 = '6';
    elseif (setting==1000)
        parameter2 = '7';
    else
        error('Invalid Input: Please enter valid voltage(5,10,20,50,100,200,500,1000)')
    end
else 
    if (setting==0)
        parameter2 = '0';
    elseif (setting==0.3)
        parameter2 = '1';
    elseif (setting==1)
        parameter2 = '2';
    elseif (setting==3)
        parameter2 = '3';
    elseif (setting==10)
        parameter2 = '4';
    elseif (setting==30)
        parameter2 = '5';
    elseif (setting==100)
        parameter2 = '6';
    elseif (setting==300)
        parameter2 = '7';
    elseif (setting==1000)
        parameter2 = '8';
    else 
        error('Invalid Input: Please enter valid frequency(0,0.3,1,3,10,30,100,300,1000)')
    end
end 
    
% create the command       
command = ['K' parameter1 parameter2];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead

% check the status code of the response
[code errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);

if(parameter1=='F' & parameter2=='0')
    M15_DcFlag = 1;
else
    M15_DcFlag = 0;
end
    
if M15_DEBUG
    settingstr = sprintf('%u',setting);
    if(parameter1=='A')
        disp(['Voltage = ' settingstr '*(10^-6)volts'])
    else
        disp(['Frequency = ' settingstr 'Hz'])
    end
end