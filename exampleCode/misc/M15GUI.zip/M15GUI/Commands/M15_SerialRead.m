%
% M15_SerialRead Read data from the device.
%
% function response = M15_SerialRead
%
% Author Aarti Goge
%
% This function is used to read a response from the serial port. 
%
% Inputs
%    none
%
% Outputs
%    response: reply from the device(string) 
%
% Globals
%    M15_SerialPort: serial port object
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function response = M15_SerialRead

% gobal variable
global M15_SerialPort M15_DEBUG;

% read data from the device
response = fscanf(M15_SerialPort);

if M15_DEBUG
    fprintf('M15_SerialRead.m: response = "%s" ', response);
end