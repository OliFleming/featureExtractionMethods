%
% M15_NCH This function is used to specify the number of amplifier
%  channels available in the amplifier system.
%
% function NCh = M15_NCH
%
% Author Adrian Chan
%
% Inputs
%    none
%
% Outputs
%    none 
%
% Modifications
% 05/09/20 AC First created.
function NCh = M15_NCH

NCh = 16;
