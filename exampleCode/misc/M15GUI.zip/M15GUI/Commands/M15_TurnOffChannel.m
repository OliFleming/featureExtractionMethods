%
% M15_TurnOffChannel Assign the input to minimum gain, gainrange, and highfilter,
% highest lowfilter and linefilter setting off.
%
% function M15_TurnOffChannel(amplifiernum)
%
% Author Aarti Goge
%
% This function is used to turn off channel(s) corresponding to appropriate amplifier
% number provided as an input. This closes the amplification down to
% minimum filter and amplification settings.
%
% Inputs
%    amplifiernum: an array of amplifier numbers, range 1 to 32(decimal)
%
% Outputs
%    none
%
% Globals
%    M15_Amplifiers: an array of amplifier numbers, range 1 to 32(decimal)
%
% Modifications
% 03/07/11 AG First created.
% 05/09/20 AC Changed function so lowfilter is set to its highest setting
% (not lowest)
function M15_TurnOffChannel(amplifiernum)

global M15_Amplifiers;

if (nargin==0)        
    amplifiernum = M15_Amplifiers;  
    if (isempty(amplifiernum))
        disp(' ')
        disp(['Please select channels through M15_AllChannelBasis...'])
    end
end

N = max(size(amplifiernum));

for(i=1:N)
    
    %check if amplifiernum is in the range: 1 to 32 
    if(amplifiernum(i)<1 | amplifiernum(i)>32)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('The system has only 8 Quad Amplifier plug-in slots. Amplifier number must be in the range: 1-32.');
    end
    
    % set minimum gain--------->will set min. gain range as 10
    M15_SetGain(50,amplifiernum(i));
    
    % set minimum high filter value
    M15_SetHighFilter(30,amplifiernum(i));
    
    % set maximum low filter value
    M15_SetLowFilter(100,amplifiernum(i));
   
    % set line filter as 'off'
    M15_SetLineFilter('off',amplifiernum(i));
   
end