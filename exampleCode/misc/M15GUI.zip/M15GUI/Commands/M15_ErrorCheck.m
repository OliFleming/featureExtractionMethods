%
% M15_ErrorCheck Check if any error has occurred at the matlab command
% prompt. If yes, then probably M15_GUI can't recover from the fault and
% need to close M15_GUI
%
% function M15_ErrorCheck(serialportname)
%
% Author Aarti Goge
%
% This function is used to save M15_GUI from past errors. 
%
% Inputs
%    none
%
% Outputs
%    none
%
% Modifications
% 03/06/18 AG First created.
%
function M15_ErrorCheck
%errmsg = lasterr
%if(strfind(errmsg, 'Error while evaluating figure CreateFcn.'))
if lasterr
      disp('--last error message:--')
      lasterror
      hError = errordlg(lasterr,'Error','on');
      waitfor(hError)
      disp('Closing Model 15 GUI')
      close('Model 15 GUI')
      exit
end