%
% M15_SetGainRange Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_SetGainRange(setting,amplifiernum)
%
% Author Aarti Goge
%
% This function is used to change the gain range setting for the designated 
% amplifier to either �10 or �1000. 
%
% Inputs
%    setting: gain range value 
%    amplifiernum: an array of amplifier numbers, range 0 to 32(decimal)
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_SetGainRange(setting,amplifiernum)

global M15_Amplifiers M15_OK M15_DEBUG;

switch nargin,   
    
    case 0        
         error('Atleast enter valid gain range setting(1000,10).'); 
         
    case 1
        % all(group) channel basis
         amplifiernum = M15_Amplifiers; 
         if (isempty(amplifiernum))
             disp(' ')
             disp(['Please select channels through M15_AllChannelBasis...'])
         end
 end

% initialize parameter1 based on setting('0' for '1000' and '1' for '10')
if (setting==1000)
    parameter1 = '0';
elseif (setting==10)
    parameter1 = '1';
else
    error('Invalid Input: Please enter setting as 1000 or 10')
end

N = max(size(amplifiernum));

for(i=1:N)
    %check if amplifiernum is 1 digit or 2 digit #, if it is >32 throw an
    %error------------------
    if(amplifiernum(i)<0)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('Amplifier number can not be negative. Please enter amplifier number is in the range: 0-32.');
    elseif(amplifiernum(i)<16)
        amplifiernumstr = sprintf('%02X',amplifiernum(i));
    elseif (amplifiernum(i)<33)
        amplifiernumstr = sprintf('%2X',amplifiernum(i));
    else 
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('The system has only 8 Quad Amplifier plug-in slots. Hence the appropriate amplifier number is in the range: 0-32.');
    end

    % create the command
    command = ['R' amplifiernumstr parameter1];

    % write the command to the serial port
    M15_SerialWrite(command);

    % read the repsponse from the serial port
    response = M15_SerialRead;

    %check the status code of the response
    [code, errormsg] = M15_StatusCode(response);

    % verify the code to check if it corresponds to 'OK'
    M15_VerifyCode(code,errormsg);
    
    if M15_DEBUG   
        if (code==M15_OK)
            amplifiernumstr = sprintf('%d',amplifiernum(i));
            settingstr = sprintf('%u',setting);
            if (amplifiernumstr=='0')
                disp(['For All Amplifiers: Gain Range = ' settingstr])
                break
            else
                disp(['Amplifier #' amplifiernumstr ': Gain Range = ' settingstr])        
            end
        else
            amplifiernumstr = sprintf('%d',amplifiernum(i));
            disp([' for ' amplifiernumstr])
        end
    end
    
end