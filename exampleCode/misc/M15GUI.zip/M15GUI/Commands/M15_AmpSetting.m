%
% M15_AmpSetting Check if the input string is complete(19 characters) and
% sort out the input into appropriate output variables. If the input string
% is incomplete then the amplifier does not exist.
%
% function [highfilter,linefilter,gainrange,gain,lowfilter] = M15_AmpSetting(response)
%
% Author Aarti Goge
%
% This function is used to sort out the response from the Model 15 into
% appropriate highfilter, linefilter, gainrange, gain and lowfilter
% setting.
%
% Inputs
%    response: an array of amplifier numbers, range 1 to 32(decimal) 
%
% Outputs
%    highfilter: high filter value(string)
%    linefilter: line filter value(string)
%    gainrange: gain range value(string)
%    gain: gain value(string)
%    lowfilter: low filter value(string)
%
% Modifications
% 03/07/11 AG First created.
%
function [highfilter,linefilter,gainrange,gain,lowfilter] = M15_AmpSetting(response)

% if the response is complete, assign output variables else the amplifier doesn't exist 
if((max(size(response)))==14)
    highfilter = response(7);
    linefilter = response(8);
    gainrange = response(9);
    amplification = response(10);
    lowfilter = response(11);
    
    % high filter
    if (highfilter=='0')
        highfilter = 30;
    elseif (highfilter=='1')
        highfilter = 100;
    elseif (highfilter=='2')
       highfilter = 300;
    elseif (highfilter=='3')
        highfilter = 1000;
    elseif (highfilter=='4')
        highfilter = 3000;
    elseif (highfilter=='5')
        highfilter = 6000;
    else
        error('Invalid Response for High Filter.');
    end     

    % line filter
    if (linefilter=='0')
        linefilter = 'OFF';
    elseif (linefilter=='1')
        linefilter = 'ON';
    else 
        error('Invalid Response for Line Filter.');
    end   

    % gain range
    if (gainrange=='0')
        gainrange = 1000;
    elseif (gainrange=='1')
        gainrange = 10;
    else
        error('Invalid Response for Gain Range.')
    end

    % gain
    if (amplification=='0')
        amplification = 5;     
    elseif (amplification=='1')
        amplification = 10;
    elseif (amplification=='2')
        amplification = 20;
    elseif (amplification=='3')
        amplification = 50;
    elseif (amplification=='4')
        amplification = 100;
    elseif (amplification=='5')
        amplification = 200;
    else
        error('Invalid Response for Gain');
    end       
    
    gain = amplification*gainrange;
    %gain = sprintf('%u',gain);
    %gainrange = sprintf('%u',gainrange);


    % low filter
    if (lowfilter=='0')
        lowfilter = 0.01;
    elseif (lowfilter=='1')
        lowfilter = 0.1;
    elseif (lowfilter=='2')
        lowfilter = 0.3;
    elseif (lowfilter=='3')
        lowfilter = 1.0;
    elseif (lowfilter=='4')
        lowfilter = 3.0;
    elseif (lowfilter=='5')
        lowfilter = 10;
    elseif (lowfilter=='6')
        lowfilter = 30;
    elseif (lowfilter=='7')
        lowfilter = 100;
    else
        error('Invalid Response for Low Filter.');
    end  

else
    % assign null values 
    highfilter = 'null';
    linefilter = 'null';
    gainrange = 'null';
    gain = 'null';
    lowfilter = 'null';
end