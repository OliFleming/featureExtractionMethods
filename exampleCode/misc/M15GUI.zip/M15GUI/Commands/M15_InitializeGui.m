%
% M15_InitializeGui Initialize global variable and invoke M15_InitializeSerialPort.
%
% function M15_InitializeGui
%
% Author Aarti Goge
%
% This function is used to in the CreateFcn of M15_GUI. 
%
% Inputs
%    none
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/08/13 AG First created.
% 03/10/07 AG Added code to set the model 15 in an 'use' mode.
%
function M15_InitializeGui

%global M15_DEBUG;   % check out M15_DEBUG in M15_InitializeSerialPort
%M15_DEBUG = 0;

% initialize serial port
M15_InitializeSerialPort;

% let model 15 know, all the amplifiers installed (default 8 amplifiers)
M15_WhoYouAre;

% set the model 15 in an 'use' mode
M15_SetMode('use');

%errmsg = lasterr;
%if(strfind(errmsg, 'Port: COM1 is not available. No ports are available.'))
%      disp('show warning dialog box!!!')
%end