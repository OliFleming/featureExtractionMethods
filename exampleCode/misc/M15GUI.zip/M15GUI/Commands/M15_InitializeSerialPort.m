%
% M15_InitializeSerialPort Create a serial port object and connect it to the device.
%
% function M15_InitializeSerialPort(serialportname)
%
% Author Aarti Goge
%
% This function is used to initialize a serial port connection with the device. 
%
% Inputs
%    serialportname: serial port name (default 'COM1')
%    M15_Address: address of the Model 15 system(default '1')
%
% Outputs
%    none
%
% Globals
%    M15_SerialPort: serial port object
%    M15_Address: address of the Model 15 system(string)
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_InitializeSerialPort(varargin) 

% global variables
global M15_SerialPort M15_Address M15_DEBUG;   

M15_DEBUG = 0;      % used for debugging purpose...if set to 1, then debugging mode...

switch nargin,
    
    case 0
        % default serial port name is 'COM3' and M15_Address is '1'
        serialportname = 'COM3';
        M15_Address = '1';
    
    case 1
        if (isnumeric(varargin{1}))
            M15_Address = sprintf('%u',varargin{1}); % write formatted data to a string
            serialportname = 'COM3';     % default serial port name is 'COM3'
        else
            serialportname = varargin{1};
            M15_Address = '1';          % default M15_Address is '1'
        end
        
    case 2
        serialportname = varargin{1};
        M15_Address = sprintf('%u',varargin{2});
        
    otherwise
        error('Wrong number of input arguments for M15_InitializeSerialPort.');
end  

% create a serial port object
M15_SerialPort = serial(serialportname);
M15_SerialPort.Terminator='CR';

% connect the serial port object to the device
fopen(M15_SerialPort)
%M15_SerialPort.Status = 'closed';
%if (M15_SerialPort.Status=='closed')
%    hWarning = warndlg('Error has occurred while connecting the serial port object to the device','Warning!!!')
%end