%
% M15_QuerySettings Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_QuerySettings(amplifiernum)
%
% Author Aarti Goge
%
% This function is used to reads back the amplifier's settings specified by the 
% amplifiernum as an input. The response will provide basic characteristics of 
% the desired amplifier(high filter, line filter, gain range, gain, low filter).
%
% Inputs
%    amplifiernum: an array of amplifier numbers, range 1 to 32(decimal)
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function [highfilter, linefilter, gain, lowfilter] = M15_QuerySettings(amplifiernum)

global M15_OK M15_Amplifiers M15_Flag M15_DEBUG;

if (nargin==0)
    % all(group) channel basis
    amplifiernum = M15_Amplifiers;   
    if (isempty(amplifiernum))
        disp(' ')
        disp(['Please select channels through M15_AllChannelBasis...'])
    end
end

N = max(size(amplifiernum));

for(i=1:N)
    %check if amplifiernum is 1 digit or 2 digit #, if it is >32 throw an
    %error------------------
    if(amplifiernum(i)<0)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('Amplifier number can not be negative. Please enter amplifier number is in the range: 1-32.');
    elseif(amplifiernum(i)==0)
        error('0 is not valid input for M15_QuerySettings. The appropriate amplifier number is in the range: 1-32')
    elseif(amplifiernum(i)<16)
        amplifiernumstr = sprintf('%02X',amplifiernum(i));
    elseif(amplifiernum(i)<33)
        amplifiernumstr = sprintf('%2X',amplifiernum(i));
    else 
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('The system has only 8 Quad Amplifier plug-in slots. Hence the appropriate amplifier number is in the range: 1-32.');
    end

    % create the command
    command = ['Q' amplifiernumstr];

    % write the command to the serial port
    M15_SerialWrite(command);

    % read the repsponse from the serial port
    response = M15_SerialRead;

    % check the status code of the response
    [code errormsg] = M15_StatusCode(response);

    % verify the code to check if it corresponds to 'OK'
    M15_VerifyCode(code,errormsg);

    setting = M15_SerialRead;
   
    if (code==M15_OK)   % if code is OK then do the following 
        [highfilter linefilter gainrange gain lowfilter] = M15_AmpSetting(setting);
        highfilterstr = sprintf('%u',highfilter);
        lowfilterstr = sprintf('%u',lowfilter);
        gainrangestr = sprintf('%u',gainrange);
        gainstr = sprintf('%u',gain);
        linefilterstr = linefilter;
            
        if M15_DEBUG 
            if (strfind(highfilter,'null'))%||(M15_Flag~=1))
                amplifier = sprintf('%u',hex2dec(amplifiernumstr));
                disp(' ')
                disp(['Amplifier #' amplifier ' does not exist.'])
                disp(' ')
            else
                disp(' ');
                disp(' ');
                amplifier = sprintf('%u',hex2dec(amplifiernumstr));
                disp(['Current Setting of amplifier #' amplifier])
                disp(' ');
                disp(['High Filter = ' highfilterstr 'Hz'])
                disp(['Line Filter = ' linefilterstr])
                disp(['Low Filter = ' lowfilterstr 'Hz'])
                disp(['Gain Range = ' gainrangestr])
                disp(['Gain = ' gainstr])
            end
        end
    else
        if M15_DEBUG
            amplifiernumstr = sprintf('%d',amplifiernum(i));
            disp([' for ' amplifiernumstr])
        end
    end
    
end  % end of for loop