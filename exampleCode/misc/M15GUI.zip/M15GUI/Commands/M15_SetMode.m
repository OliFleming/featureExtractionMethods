%
% M15_SetMode Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_SetMode(setting)
%
% Author Aarti Goge
%
% This function is used to sets the Model 15 into either the Calibration or Use
% mode (to switch all of the amplifier inputs to either the calibrator circuit or 
% the electrode inputs).
%
% Inputs
%    setting: 'use' or 'cal' mode
%
% Outputs
%    none
%
% Globals
%    M15_CalFlag: calibration mode flag (if the mode is set to calibration,
%    M15_CalFlag is set to 1, else 0)
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_SetMode(setting)

global M15_OK M15_CalFlag M15_DEBUG;

if(nargin==0)
    % default setting is 'use' mode
    setting = 'use';   
end

% initialize parameter1 based on setting('0' for 'use' and '1' for 'cal')
if (strcmpi(setting,'use'))
    parameter1 = '0';
    M15_CalFlag = 0;   % not in cal mode--cal flag off
elseif (strcmpi(setting,'cal'))
    parameter1 = '1';
    M15_CalFlag = 1;    % in cal mode--cal flag on
else
    %handle = warndlg('Please enter proper mode: use or cal','Warning!!!');
     error('Invalid Input: Please enter valid input as cal or use(case insensitive)');
end

% create the command
command = ['C' parameter1];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead;

% check the status code of the response
[code errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);

if M15_DEBUG
    if (code==M15_OK)
        disp(' ')
        disp(['Mode = ' setting])
    end
end