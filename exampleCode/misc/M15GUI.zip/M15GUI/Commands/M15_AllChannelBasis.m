%
% M15_AllChannelBasis Initialize the global varaible, M15_Amplifiers as per
% the input. If input is not in the range 1-32, then throw an error message.
%
% function M15_AllChannelBasis(amplifiernum)
%
% Author Aarti Goge
%
% This function is used to initialize an array of amplifiers in an
% all channel basis.
%
% Inputs
%    amplifiernum: an array of amplifier numbers, range 1 to 32(decimal) 
%
% Outputs
%    none
%
% Globals
%   M15_Amplifiers: an array of amplifier numbers, range 1 to 32(decimal)
%
% Modifications
% 03/07/11 AG First created.
%
function M15_AllChannelBasis(amplifiernum)

global M15_Amplifiers;

if (nargin==0)
    % default is all channels for the current amp. system
    amplifiernum = [1:8];
    % M15_Amplifiers = 0;
end
        
% throw an error if input array has value outside the range 1-32
N = max(size(amplifiernum));
for(i=1:N)
    %check if amplifiernum is in the range: 1 to 32 
    if(amplifiernum(i)<1 | amplifiernum(i)>32)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('The system has only 8 Quad Amplifier plug-in slots. Input must be in the range: 1-32.');
    end
end

M15_Amplifiers = amplifiernum;