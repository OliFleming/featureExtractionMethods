%
% M15_SetGain Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_SetGain(setting,amplifiernum)
%
% Author Aarti Goge
%
% This function is used to change the gain setting for the designated amplifier to 
% the setting represented by the input. The overall gain for the channel is the product 
% of the gain range and the gain setting.
%
% Inputs
%    setting: gain value 
%    amplifiernum: an array of amplifier numbers, range 0 to 32(decimal)
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function error = M15_SetGain(setting,amplifiernum)

global M15_Amplifiers M15_OK M15_DEBUG;
error = 0;

switch nargin,   
    
    case 0        
         error('Atleast enter gain setting.'); 
         
    case 1
        % all(group) channel basis
         amplifiernum = M15_Amplifiers; 
         if (isempty(amplifiernum))
             disp(' ')
             disp(['Please select channels through M15_AllChannelBasis...'])
         end
 end
 
 if(setting<0)
     error('Gain can not be negative.')
 elseif(setting<5000)
    if(setting<50)
        disp(['The minimum gain seting is 50.'])
        amplification = 5;
        gainrange = 10;
    else
        gainrange = 10;
        amplification = setting/gainrange;
    end
elseif(setting>200000)
    disp(['The maximum gain seting is 200000.'])
    gainrange = 1000;
    amplification = 200;
else
     gainrange = 1000;
     amplification = setting/gainrange;
 end
 
% initialize parameter1 based on setting
% Astro-Med Inc., Grass 15 & 15LT Amplifier System - Instruction/User Manual, Release A Grass
% Telefactor, West Warwick RI, 2002, p. A-7
 %-------------------------------------------check for error throw?
 if(amplification<10)
     amplification = 5;
     parameter1 = '0';
 elseif(amplification<20)
     amplification = 10;
     parameter1 = '1';
 elseif(amplification<50)
     amplification = 20;
     parameter1 = '2';
 elseif(amplification<100)
     amplification = 50;
     parameter1 = '3';
 elseif(amplification<200)
     amplification = 100;
     parameter1 = '4';
 else
     amplification = 200;
     parameter1 = '5';
 end
     
N = max(size(amplifiernum));

for(i=1:N)
    %check if amplifiernum is 1 digit or 2 digit #, if it is >32 throw an
    %error------------------
    if(amplifiernum(i)<0)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('Amplifier number can not be negative. Please enter amplifier number is in the range: 0-32.');
    elseif(amplifiernum(i)<16)
        amplifiernumstr = sprintf('%02X',amplifiernum(i));
    elseif (amplifiernum(i)<33)
        amplifiernumstr = sprintf('%2X',amplifiernum(i));
    else 
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('The system has only 8 Quad Amplifier plug-in slots. Hence the appropriate amplifier number is in the range: 0-32.');
    end

    % set appropriate gain range
    M15_SetGainRange(gainrange,amplifiernum(i));
 
    % create the command
    command = ['G' amplifiernumstr parameter1];

    % write the command to the serial port
    M15_SerialWrite(command);

    % read the repsponse from the serial port
    response = M15_SerialRead;

    % check the status code of the response
    [code, errormsg] = M15_StatusCode(response);

    % verify the code to check if it corresponds to 'OK'
    M15_VerifyCode(code,errormsg);
        
    if (code==M15_OK)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
    
        if (amplifiernumstr=='0')
            % current M15 has only 8 amplifiers
            for i=1:8
                [highfilter linefilter gain lowfilter] = M15_QuerySettings(amplifiernum(i));
                gainstr = sprintf('%u',gain);
                if (setting~=gain)
                    disp('M15_SetGain: Error has occured, query does not confirm the write operation')  
                    error = 1;
                    return
                end
            end
            if M15_DEBUG
                disp(['For All Amplifiers: Gain = ' gainstr])
                break
            end
        else
            [highfilter linefilter gain lowfilter] = M15_QuerySettings(amplifiernum(i));
            gainstr = sprintf('%u',gain);
            if (setting==gain)    
                if M15_DEBUG
                    disp(['Amplifier #' amplifiernumstr ': Gain = ' gainstr])
                end
            elseif (strfind(gain,'null')) % for current M15, 9-32 amplifiers get 'null' response from M15_QuerySettings               
                disp('M15_SetGain: Error has occured, query does not confirm the write operation')
                error = 1;
                return
            end   
        end
            
    else
        if M15_DEBUG
            amplifiernumstr = sprintf('%d',amplifiernum(i));
            disp([' for ' amplifiernumstr])
        end
    end
      
end % end of for loop