%
% M15_DcCalEnable Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_DcCalEnable(setting)
%
% Author Aarti Goge
%
% This function is used to apply or remove a DC calibration signal, when the 
% system is in the Calibration mode and the frequency is set to 0 for DC.
%
% Inputs
%    setting: DC Cal Enable 'off' or 'on' 
%
% Outputs
%    none
%
% Globals
%    M15_CalFlag: calibration mode flag (if the mode is set to calibration,
%    M15_CalFlag is set to 1, else 0)
%    M15_DcFlag: DC flag (if the frequency is set to 0 for DC then the flag
%    is set to 1, else 0)
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_DcCalEnable(setting)

global M15_OK M15_CalFlag M15_DcFlag M15_DEBUG;

if(M15_CalFlag~=1 | M15_DcFlag~=1)
    error('The system must be in Calibration mode and the frequency must be set to 0 in order to apply/remove a DC calibration signal.')
end

%if(M15_DcFlag~=1)
%    error('For M15_DcCalEnable: the frequency must be set to 0 for DC.')
%end

if(nargin==0)
    error('Please enter the setting as off or on for M15_DcCalEnable.');
end

% initialize parameter1 based on setting('0' for 'off' and '1' for 'on')
if (strcmpi(setting,'off'))
    parameter1 = '0';
elseif (strcmpi(setting,'on'))
    parameter1 = '1';
else
    error('Invalid Input: Please enter valid input as off or on(case insensitive)');
end

% create the command
command =  ['D' parameter1];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead

% check the status code of the response
[code errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);

if M15_DEBUG
    if (code==M15_OK)
        disp(['DC Cal Enable = ' setting])
    end
end