%
% M15_QueryStatus Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_QueryStatus
%
% Author Aarti Goge
%
% This function is used to checks the status of the Model 15 and responds with 
% either 'OK' or the last encountered error code 'XX'.
%
% Inputs
%    none
%
% Outputs
%    none
%
% Modifications
% 03/06/18 AG First created.
%
function M15_QueryStatus

% create the command
command = ['E'];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead;

% check the status code of the response
[code errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);