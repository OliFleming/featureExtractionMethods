%
% M15_DestroySerialPort Disconnect a serial port object from the device.
%
% function M15_DestroySerialPort
%
% Author Aarti Goge
%
% This function is used to destroy a serial port connection with the device. 
%
% Inputs
%    none
%
% Outputs
%    none
%
% Globals
%    M15_SerialPort: serial port object
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_DestroySerialPort 

% global variable 
global M15_SerialPort;   
global M15_DEBUG

% disconnect the serial port object from the device
fclose(M15_SerialPort)

if M15_DEBUG
    fprintf('M15_DestroySerialPort');
end
