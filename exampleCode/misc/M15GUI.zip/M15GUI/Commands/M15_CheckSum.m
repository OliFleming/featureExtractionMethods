%
% M15_CheckSum Add all the bytes to be sent, including the escape
% character, but not including the checksum or final carriage return. 
%
% function checksum = M15_CheckSum(command)
%
% Author Aarti Goge
%
% This function is used to sum all the bytes in the command. 
%
% Inputs
%    command: ASCII string beginning with the ASCII escape character
%
% Outputs
%    checksum: sum of all bytes in the command (2-byte, ASCII encoded
%    hexadecimal and is truncated to lower 2 bytes, if necessary)
%
% Example
%    A checksum of 243 decimal (F3 hex) must be transmitted as the 2 characters 'F'
%    followed by '3'.
%
% Modifications
% 03/06/18 AG First created.
%
function checksum = M15_CheckSum(command)

% sum the command and write formatted data to a string
checksum = sprintf('%X',sum(abs(command)));

% get length of a vector checksum
N = length(checksum);

% if length of the checksum is more than 2 bytes then truncate it to 2 bytes
if N > 2
    checksum = checksum(N-1:N);
end

% if length of the checksum is 1 byte then add '0' in the beginning to make it
% 2 bytes
if N < 2
    checksum = ['0' checksum];  
end