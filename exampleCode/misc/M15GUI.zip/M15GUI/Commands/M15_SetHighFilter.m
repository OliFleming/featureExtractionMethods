%
% M15_SetHighFilter Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_SetHighFilter(setting,amplifiernum)
%
% Author Aarti Goge
%
% This function is used to change the high-filter setting for the designated 
% amplifier to the setting represented by the input.
%
% Inputs
%    setting: high filter value 
%    amplifiernum: an array of amplifier numbers, range 0 to 32(decimal)
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function error = M15_SetHighFilter(setting,amplifiernum)

global M15_Amplifiers M15_OK M15_DEBUG;
error = 0;

switch nargin,
    
    case 0        
         error('Atleast enter valid high filter setting(30,100,300,1000,3000,6000).');     
        
    case 1
        % all(group) channel basis
         amplifiernum = M15_Amplifiers;
         if (isempty(amplifiernum))
             disp(' ')
             disp(['Please select channels through M15_AllChannelBasis...'])
         end
 end

% initialize parameter1 based on setting
if (setting==30)
    parameter1 = '0';
elseif (setting==100)
    parameter1 = '1';
elseif (setting==300)
    parameter1 = '2';
elseif (setting==1000)
    parameter1 = '3';
elseif (setting==3000)
    parameter1 = '4';
elseif (setting==6000)
    parameter1 = '5';
else
    error('Invalid Input: Please enter valid setting(30,100,300,1000,3000,6000)');
end     

%check if amplifiernum is in the range (0???)1 to 32
% create string of amplifiernum, what if it is 2 digit num-----don't need
% to add 0 at the beginning of the string-----use--max(size(X)) to check
N = max(size(amplifiernum));

for(i=1:N)
    %check if amplifiernum is 1 digit or 2 digit #, if it is >32 throw an
    %error------------------
    if(amplifiernum(i)<0)
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('Amplifier number can not be negative. Please enter amplifier number is in the range: 0-32.');
    elseif(amplifiernum(i)<16)
        amplifiernumstr = sprintf('%02X',amplifiernum(i));
    elseif (amplifiernum(i)<33)
        amplifiernumstr = sprintf('%2X',amplifiernum(i));
    else 
        amplifiernumstr = sprintf('%d',amplifiernum(i));
        disp([amplifiernumstr ' is not a valid input']) 
        error('The system has only 8 Quad Amplifier plug-in slots. Hence the appropriate amplifier number is in the range: 0-32.');
    end
    
    % create the command
    command = ['H' amplifiernumstr parameter1];
    
    % write the command to the serial port
    M15_SerialWrite(command);

    % read the repsponse from the serial port
    response = M15_SerialRead;

    % check the status code of the response
    [code, errormsg] = M15_StatusCode(response);

    % verify the code to check if it corresponds to 'OK'
    M15_VerifyCode(code,errormsg);

    if (code==M15_OK)
            amplifiernumstr = sprintf('%d',amplifiernum(i));
            settingstr = sprintf('%u',setting);
            if (amplifiernumstr=='0')
                % current M15 has only 8 amplifiers
                for i=1:8
                    [highfilter linefilter gain lowfilter] = M15_QuerySettings(amplifiernum(i));
                    if (setting~=highfilter)
                        disp('M15_SetHighFilter: Error has occured, query does not confirm the write operation')  
                        error = 1;
                        return
                    end
                end
                if M15_DEBUG
                    disp(['For All Amplifiers: High Filter = ' settingstr 'Hz'])
                    break
                end
            else
                [highfilter linefilter gain lowfilter] = M15_QuerySettings(amplifiernum(i));
                highfilterstr = sprintf('%u',highfilter);
                if (setting==highfilter)     
                    if M15_DEBUG
                        disp(['Amplifier #' amplifiernumstr ': HighFilter = ' highfilterstr 'Hz']) 
                    end
                elseif (strfind(highfilter,'null')) % for current M15, 9-32 amplifiers get 'null' response from M15_QuerySettings               
                    disp('M15_SetHighFilter: Error has occured, query does not confirm the write operation')
                    error = 1;
                    return
                end   
                   
            end
    else
        if M15_DEBUG
            amplifiernumstr = sprintf('%d',amplifiernum(i));
            disp([' for ' amplifiernumstr])
        end
    end
    
end % end of for loop