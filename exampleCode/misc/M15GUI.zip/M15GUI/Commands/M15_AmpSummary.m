
%
% M15_AmpSummary
%
% function M15_AmpSummary(amplifiernum)
%
% Author Aarti Goge
%
% This function is used to turn off channel(s) corresponding to appropriate amplifier
% number provided as an input. This closes the amplification down to
% minimum filter and amplification settings.
%
% Inputs
%    amplifiernum: an array of amplifier numbers, range 1 to 32(decimal)
%
% Outputs
%    none
%
% Globals
%    M15_Amplifiers: an array of amplifier numbers, range 1 to 32(decimal)
%
% Modifications
% 03/07/11 AG First created.
%
function M15_AmpSummary(amplifiernum)

%N = max(size(amplifiernum))
for(i=1:8)
    %check if the amplifiernum is within 1 to 8 for the current system
    M15_QuerySettings(amplifiernum(i))
end