% Model 15 Amplifier System Commands.
% Version 0.0.1  19-Apr-2005
%
% Commands.
% 	M15_GUI                     - GUI for Model 15.
% 	M15_About                   - Open 'About Model 15' window. Associated with help menu.
% 	M15_Initialize              - Initialize all amplifiers to non-volatile default settings.
% 	M15_InitializeGUI           - Initialize GUI for Model 15.
% 	M15_InitializeSerialPort    - Initialize serial port connection with device.
% 	M15_AllChannelBasis         - Initialize channels.
% 	M15_DestroyGui              - Destroy GUI.
% 	M15_DestroySerialPort       - Disconnect serial port object from device.
% 	M15_TurnOffChannel          - Turn off channel.
% 	M15_QueryID                 - Obtain Model 15 firmware revision number.
% 	M15_QuerySettings           - Determine filter characteristics from amplifier settings.
% 	M15_QueryStatus             - Check status of Model 15.
% 	M15_SetGain                 - Set amplifier gain setting.
% 	M15_SetGainRange            - Set amplifier gain range setting.
% 	M15_SetHighFilter           - Change amplifier high filter setting.
% 	M15_SetLineFilter           - Change amplifier line frequency filter setting.
% 	M15_SetLowFilter            - Change amplifier low filter setting.
% 	M15_SaveDefaults            - Save current settings to non-volatile memory as start-up settings.
% 	M15_SerialRead              - Read response from serial port.
% 	M15_SerialWrite             - Write command to serial port.
% 	M15_AmpSetting              - Sort response of Model 15 into filter and gain settings.
% 	M15_AmpSummary              - Turn off amplifier channel.
% 	M15_SetMode                 - Switch Model 15 into Calibration or Use mode.
% 	M15_CalSettings             - Calibrate frequency and amplitude.
% 	M15_DcCalEnable             - Apply or remove DC calibration signal.
% 	M15_CheckSum                - Sum all bytes in command.
% 	M15_ErrorCheck              - Check if error has occurred at Matlab prompt.
% 	M15_StatusCode              - Resolve response into corresponding error code and message.
% 	M15_VerifyCode              - Output message according to error code.
% 	M15_TraceRestore            - Apply or remove trace restore function (clamp amplifiers).
% 	M15_ElectrodeTest           - Initiate electrode test sequence.
% 	M15_TestProgram             - Test all commands and functions to be sent to Model 15 amplifier system.
% 	M15_WhoYouAre               - Tells Model 15 what type of amplifier module is in each slot.
% 
% See also M15_GUI.

%   Copyright 2004-2005 Adrian Chan
%   $Revision: 1.1 $  $Date: 2005/04/19 12:00:00 $