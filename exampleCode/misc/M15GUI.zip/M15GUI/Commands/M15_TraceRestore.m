%
% M15_TraceRestore Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_TraceRestore(setting)
%
% Author Aarti Goge
%
% This function is used to apply or remove the trace restore function(clamp amplifiers).
%
% Inputs
%    setting: trace restore 'off' or 'on' 
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_TraceRestore(setting)

global M15_DEBUG;

if(nargin==0)
    error('Pleaes enter the setting as off or on for M15_TraceRestore.');
end

% initialize parameter1 based on setting('0' for 'off' and '1' for 'on')
if (strcmpi(setting,'off'))
    parameter1 = '0';
elseif (strcmpi(setting,'on'))
    parameter1 = '1';
else
    error('Invalid Input: Please enter valid input as off or on(case insensitive)');
end

% create the command
command = ['A' parameter1];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead

% check the status code of the response
[code, errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);

if M15_DEBUG
    disp(['Trace Restore = ' setting])
end