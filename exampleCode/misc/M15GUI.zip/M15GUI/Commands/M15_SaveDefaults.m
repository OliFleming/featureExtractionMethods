%
% M15_SaveDefaults Create and write the command to be sent to the serial port.
% Read the response from the serial port. Check the status code of the response 
% and verify the code to check if it is 'OK'.
%
% function M15_SaveDefaults
%
% Author Aarti Goge
%
% This function is used to save the current settings to the non-volatile memory 
% so that the amplifiers are initialized to these stored settings on power up.
%
% Inputs
%    setting: electrode test 'off' or 'on' 
%
% Outputs
%    none
%
% Globals
%    M15_DEBUG: constant value for debugging purposes, M15_DEBUG = 1
%
% Modifications
% 03/06/18 AG First created.
% 03/08/08 AG Introduced global variable M15_DEBUG for debugging purposes.
%
function M15_SaveDefaults

global M15_DEBUG;

% create the command
command = ['Z'];

% write the command to the serial port
M15_SerialWrite(command);

% read the repsponse from the serial port
response = M15_SerialRead

% check the status code of the response
[code, errormsg] = M15_StatusCode(response);

% verify the code to check if it corresponds to 'OK'
M15_VerifyCode(code,errormsg);

if M15_DEBUG
    disp('M15_SaveDefaults.m: saved default values.')
end